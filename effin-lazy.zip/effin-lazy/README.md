### What is this repository for? ###

This is the V2 theme for EffinLazy.com.

### How do I get set up? ###

* Install Wordpress V5 or later
* Upload theme to wp-content
* Install ACF ( Advanced Custom Fields)

### Who do I talk to? ###

* Theme developer at tyronhayman.me
